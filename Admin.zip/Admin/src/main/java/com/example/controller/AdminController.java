package com.example.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.entity.Admin;
import com.example.service.AdminService;

@RestController
public class AdminController {

    @Autowired
    private AdminService adminService;

    @PostMapping("/admins")
    public Admin saveAdmin(@RequestBody Admin admin) {
        return adminService.saveAdmin(admin);
    }

    @GetMapping("/admins")
    public List<Admin> fetchAdminList() {
        return adminService.fetchAdminList();
    }

    @GetMapping("/admins/{id}")
    public Admin fetchAdminById(@PathVariable("id") Long id) {
        return adminService.fetchAdminById(id);
    }

    @DeleteMapping("/admins/{id}")
    public String deleteAdminById(@PathVariable("id") Long id) {
        adminService.deleteAdminById(id);
        return "Admin deleted successfully!";
    }
}
